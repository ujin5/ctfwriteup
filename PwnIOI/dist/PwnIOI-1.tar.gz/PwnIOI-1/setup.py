from distutils.core import setup
 
setup(
    name = "PwnIOI",
    version = "1",
    author = "Pwn, Exam, IOI, Repeat",
    author_email = "pwn_expoit@naver.com",
    py_modules=['PwnIOI'],
    url = "http://produce102.com/",
    description = "IOI forever",
)
